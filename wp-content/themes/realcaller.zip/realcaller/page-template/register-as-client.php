<?php 
/*
    Template Name: Registration

*/

?>
<?php  get_header('dashboard');?>
<section class="register" id="register">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo bloginfo('template_url');?>/assets/images/logo.png" class="w-50">
            </div>
            <div class="col-md-6"></div>
        </div>
    </div>
    <div id="registration_dealder" class="container">
        <div class="row ">
            <div class="col-md-7 m-auto py-5">
                <h1 class="pb-4">Client Registration</h1>
                <p>Nisl blandit molestie aliquam viverra sapien congue odio.</p>
                <form method="POST">
                <div class="mb-3">
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" id="firstname" name="first_name" placeholder="First Name" aria-describedby="Firstname">
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" id="lastname" name="last_name"   placeholder="Last Name"aria-describedby="Lastname">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <input type="email" class="form-control" id="email_address" name="email" placeholder="Email address" aria-describedby="email address">
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
                </div>

                <div class="mb-3">
                    <input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Contact Number">
                </div>
                <button id="register_client_1" type="submit" name="register_client_1" class="w-100 btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php  get_footer('login');?>
<?php
/**
 * Silence is golden.
 *
 * @package WKWC Addons
 */

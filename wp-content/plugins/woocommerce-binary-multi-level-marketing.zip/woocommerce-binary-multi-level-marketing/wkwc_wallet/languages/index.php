<?php
/**
 * Silence is golden.
 *
 * Path: /woocommerce3.0-plugins/submodules/wkwc_wallet
 *
 * @package WKWC_Wallet
 */

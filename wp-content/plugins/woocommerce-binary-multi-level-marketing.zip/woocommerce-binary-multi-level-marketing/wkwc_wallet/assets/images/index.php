<?php
/**
 * Silence is golden.
 *
 * @package WKWC_Wallet
 */

<?php
/**
 * Silence is golden.
 *
 * @package WooCommerce Binary Multi Level Marketing
 */
